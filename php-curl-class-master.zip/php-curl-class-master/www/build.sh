docker build \
    --tag php-curl-class/php-curl-class:latest \
    .
